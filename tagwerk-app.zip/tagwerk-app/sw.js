const CACHE='tagwerk-v2';
const CORE=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./icon-maskable-512.png','./apple-touch-icon.png','./sortable.min.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;
  const put=res=>{if(res&&(res.ok||res.type==='opaque')){const cp=res.clone();caches.open(CACHE).then(c=>c.put(r,cp))}return res};
  if(r.mode==='navigate'){ // neueste Version bevorzugen, offline aus dem Cache
    e.respondWith(fetch(r).then(put).catch(()=>caches.match(r).then(h=>h||caches.match('./index.html'))));return}
  e.respondWith(caches.match(r).then(hit=>{const net=fetch(r).then(put).catch(()=>hit);return hit||net}));
});
